
#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <SDL2/SDL_mixer.h>
#include <iostream>
#include <cstdlib>


#define LARGURA_TELA 640
#define ALTURA_TELA 480
#define PLAYER1 "Personagem.png"


using namespace std;

class Sdl {
public:

    SDL_Window *janela;
    SDL_Renderer *renderizacao;
    SDL_Texture *tela1, *tela2;
    SDL_Event acaoJogador;
    Mix_Music *musica;


    SDL_Rect fundo1, fundo2;

    Sdl() {


        fundo1.h = ALTURA_TELA;
        fundo1.w = LARGURA_TELA;
        fundo1.x = 0;
        fundo1.y = 0;

        fundo2.h = ALTURA_TELA;
        fundo2.w = LARGURA_TELA / 3;
        fundo2.x = 0;
        fundo2.y = 0;

        janela = NULL;
        renderizacao = NULL;
        tela1 = NULL;
        tela2 = NULL;
        musica = NULL;

        SDL_Init(SDL_INIT_EVERYTHING);
    }

    void finalizaSdl() {
        cout << "Finalizando SDL.." << endl;

        SDL_DestroyRenderer(renderizacao);
        SDL_DestroyTexture(tela1);
        SDL_DestroyTexture(tela2);
        SDL_DestroyWindow(janela);
        Mix_FreeMusic(musica);
        SDL_Quit();
        exit(1);
    }

    void carregamusica() {
        if (SDL_Init(SDL_INIT_AUDIO) < 0) {
            cout << "Erro ao inicializar o procedimento de audio\n" << endl;
        } else {
            Mix_OpenAudio(24100, AUDIO_S16SYS, 2, 1024);
            musica = Mix_LoadMUS("Clasicos de Atari - Musica de PUSS.mp3");
        }
        Mix_PlayMusic(musica, -1);
    }

    bool verificaClique(SDL_Rect rect) {
        int posicaoXmouse, posicaoYmouse;

        if (acaoJogador.type == SDL_MOUSEBUTTONDOWN) {

            SDL_GetMouseState(&posicaoXmouse, &posicaoYmouse);
            if (((posicaoXmouse > rect.x) && (posicaoXmouse < rect.w + rect.x))
                    && ((posicaoYmouse > rect.y) && (posicaoYmouse < rect.h + rect.y))) {
                return true;
            } else {
                return false;
            }
        }

        return false;
    }

    bool verificaFimJanela() {
        if (acaoJogador.type == SDL_QUIT) {
            finalizaSdl();
        }
        return false;
    }




};

class Fisica {
private:
    int velocidade, aceleracao, velocidademaxima, massa = 3;
    int tempoinit, tempofinal;




public:
    // Fisica(int mas){
    //massa = mas;


    // }

    int calculavelocidade(int forca, int velocmax) {
        aceleracao = forca / massa;
        velocidademaxima = velocmax;
        if (velocidade < velocidademaxima) {
            velocidade = velocidade + aceleracao * 1;

            return velocidade;
        } else return velocidademaxima;


    }

};

class Personagem {
public:
    SDL_Texture *imagemPersonagem;
    SDL_Rect posicaoPersonagem;
    int etapasMovimento;
    int vidas;

    void criaPersonagem(int x, int y, int w, int h, int vidas) {
        this->posicaoPersonagem.x = x;
        this->posicaoPersonagem.y = y;
        this->posicaoPersonagem.w = w;
        this->posicaoPersonagem.h = h;

    }

    void moveHorizontal(int x) {
        this->posicaoPersonagem.x += x;


    }

    void moveVertical(int y) {
        this->posicaoPersonagem.y += y;

    }
};

class Tela {
public:
    Personagem jogador; //cria um objeto jogador
    bool aux;
    SDL_Rect vida1;
    Sdl sdlvar;
    Fisica fisicajogador;
    Sdl sdlmapa;

    Tela() {
        if (criaJanela() != true)
            exit(0);
        sdlvar.renderizacao = SDL_CreateRenderer(sdlvar.janela, -1,
                SDL_RENDERER_TARGETTEXTURE);
        if (sdlvar.renderizacao == NULL) { //indetifica um erro na renderizacao
            cout << "Erro ao criar renderizacao" << endl;
            exit(1);
        }
        aux = false;

    }

    void atualizaJogador(Personagem *player) {

        SDL_RenderCopy(sdlmapa.renderizacao, player->imagemPersonagem, NULL, &player->posicaoPersonagem); //renderiza o jogador na tela

    }

    bool criaJanela() {
        sdlvar.janela = SDL_CreateWindow("2D Game", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
                LARGURA_TELA, ALTURA_TELA, SDL_WINDOW_SHOWN);

        if (sdlvar.janela == NULL) {
            cout << "Erro ao abrir janela" << endl;
            return false;
        }
        return true;
    }

    bool telaInicial(int *escolha) // 1(inicio jogo) 2()
    {
        SDL_Rect botaoIniciar = {282, 140, 326, 133};
        SDL_Rect botaoSair = {280, 295, 317, 259};

        if ((SDL_PollEvent(&sdlvar.acaoJogador))
                && (sdlvar.acaoJogador.type == SDL_MOUSEBUTTONDOWN)) {
            //clicou no botao de iniciar
            if (sdlvar.verificaClique(botaoIniciar) == true) {
                *escolha = 1;
                return false;
            }

            //clicou no botao de sair
            if (sdlvar.verificaClique(botaoSair) == true) {
                *escolha = 3;
                return false;
            }
        }

        sdlvar.verificaFimJanela();

        if (aux == false) {

            sdlvar.tela2 = IMG_LoadTexture(sdlvar.renderizacao, "Menu.jpg");
            aux = true;


            if (sdlvar.tela2 == NULL) //erro ao carregar imagem
            {
                cout << "Erro ao carregar imagem do menu!" << endl;
                exit(1);
            }
        }

        SDL_RenderCopy(sdlvar.renderizacao, sdlvar.tela2, NULL, NULL);
        SDL_RenderPresent(sdlvar.renderizacao);

        return true;
    }

    bool telaJogo() {
        sdlvar.tela1 = IMG_LoadTexture(sdlvar.renderizacao, "Mapa.jpeg");

        if (sdlvar.tela1 == NULL) //erro ao carregar imagem
        {
            cout << "Erro ao carregar imagem do jogo!" << endl;
            sdlvar.finalizaSdl();
        }

        jogador.criaPersonagem(5, ALTURA_TELA - 80, 50, 50, 1); // inicia os valores para o jogador


        jogador.imagemPersonagem = IMG_LoadTexture(sdlvar.renderizacao, PLAYER1); // carrega a imgagem do jogador

        if (jogador.imagemPersonagem == NULL) {
            cout << "Erro ao carregar imagem do personagem" << endl;
            return false;
        }



        SDL_RenderCopy(sdlvar.renderizacao, sdlvar.tela1, &sdlvar.fundo2, &sdlvar.fundo1);
        SDL_RenderCopy(sdlvar.renderizacao, jogador.imagemPersonagem, NULL, &jogador.posicaoPersonagem);
        SDL_RenderPresent(sdlvar.renderizacao);
        return true;
    }

    //atualiza a tela do personagem de acordo com o comando passado pelo usuario pelo teclado

    void realizaMovimento() {


        int velocidade;


        switch (sdlvar.acaoJogador.key.keysym.sym) {
            case SDLK_LEFT:
                if (sdlvar.fundo2.x > 0) {
                    velocidade = fisicajogador.calculavelocidade(-1, -4);
                    sdlvar.fundo2.x = sdlvar.fundo2.x + velocidade;
                    SDL_RenderCopy(sdlvar.renderizacao, sdlvar.tela1, &sdlvar.fundo1, &sdlvar.fundo2);
                    jogador.moveHorizontal(velocidade);
                }



                break;
            case SDLK_RIGHT:
                if (sdlvar.fundo2.x < 1100) {
                    velocidade = fisicajogador.calculavelocidade(4,8);
                    sdlvar.fundo2.x = sdlvar.fundo2.x + velocidade;
                    SDL_RenderCopy(sdlvar.renderizacao, sdlvar.tela1, &sdlvar.fundo1, &sdlvar.fundo2);
                    jogador.moveHorizontal(velocidade);
                }




                break;
                //    case SDLK_UP: //Pulo
                //sdlvar.fundo2.y = sdlvar.fundo2.y - 3;
                //SDL_RenderCopy(sdlvar.renderizacao, sdlvar.tela1, &sdlvar.fundo1, &sdlvar.fundo2);

                //jogador.moveVertical(-3);
                //lado = 'c';
                //break;



        }
    };
};

class Jogo : public Tela {
public:

    Jogo() {
        int escolha;
        //enquanto o jogador nao clicar no 'x' o programa continuara rodando     
        sdlvar.carregamusica();

        while (sdlvar.acaoJogador.type != SDL_QUIT) {
            aux = false;
            //abre a tela inicial e so finaliza caso o jogador clique em algo
            while (telaInicial(&escolha) == true) {
                SDL_RenderCopy(sdlvar.renderizacao, sdlvar.tela2, NULL, NULL);
                SDL_RenderPresent(sdlvar.renderizacao);
            }
            switch (escolha) {
                case 1: //tela do jogo
                    //abre a tela do jogo
                    telaJogo();
                    while ((sdlvar.verificaFimJanela() == false) && (fimJogo() == false)) {
                        loopJogo();
                    }
                    break;
                case 2:
                    sdlvar.finalizaSdl();
                    break;
                case 3: //sair
                    sdlvar.finalizaSdl();
                    break;
            }
        }
        sdlvar.finalizaSdl();
    }

    void iniciaTexturas() {
        SDL_RenderCopy(sdlvar.renderizacao, sdlvar.tela1, &sdlvar.fundo2, &sdlvar.fundo1);
        SDL_RenderCopy(sdlvar.renderizacao, jogador.imagemPersonagem, NULL, &jogador.posicaoPersonagem);
        SDL_RenderPresent(sdlvar.renderizacao);
    }

    void loopJogo() {

        //iniciaTexturas();
        while ((sdlvar.verificaFimJanela() == false) && (fimJogo() == false)) {
            if (SDL_PollEvent(&sdlvar.acaoJogador)) {
                realizaMovimento(); //faz a movimentaçao do jogador de acordo com a tecla q ele aperta
            }
            SDL_RenderCopy(sdlvar.renderizacao, sdlvar.tela1, &sdlvar.fundo2, &sdlvar.fundo1);
            SDL_Delay(8);
            atualizaJogador(&jogador);
            SDL_RenderPresent(sdlvar.renderizacao);
        }
    }

    bool fimJogo() {
        SDL_Rect botaoMenu = {335, 544, 90, 44};
        if (sdlvar.acaoJogador.type == SDL_MOUSEBUTTONDOWN) {
            if (sdlvar.verificaClique(botaoMenu) == true)
                return true;
        }
        if (jogador.vidas == 0)
            return true;
        return false;
    }
};

int main(int argc, char* argv[]) {
    Jogo BlazeToolDuel;
    return 0;
};